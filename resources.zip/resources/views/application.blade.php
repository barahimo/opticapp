@extends('layout.dashboard')
@section('contenu')
{{-- BEGIN PHP --}}
<?php
    $nbclients = App\Client::get()->count();
    $nbcategories = App\Categorie::get()->count();
    $nbproduits = App\Produit::get()->count();
    $nbcommandes = App\Commande::get()->count();
    $nbreglements = App\Reglement::get()->count();
    $nbfactures = App\Facture::get()->count();
    $clients = App\Client::orderBy('id','desc')->limit(3)->get();
    $categories = App\Categorie::orderBy('id','desc')->limit(3)->get();
    $produits = App\Produit::orderBy('id','desc')->limit(3)->get();
    $commandes = App\Commande::with('client')->orderBy('id','desc')->limit(3)->get();
    $reglements = App\Reglement::with(['commande'=>function($query){
        $query->with('client');
    }])->orderBy('id','desc')->limit(3)->get();
    $factures = App\Facture::with(['commande'=>function($query){
        $query->with('client');
    }])->orderBy('id','desc')->limit(3)->get();
    ?>
{{-- END PHP --}}
<style>
    .main-content {
        position: relative;
        margin-left:240px;
    }

    /* main{ 
        margin-top: 60px ;
        background: #f1f5f9;
        min-height: 98vh;
        padding: 1rem 3rem;
    } */

    .dash-title{
        color: var(--color-dark) ;
        margin-bottom: 1rem;
        padding: 1rem 3rem;
        
    }
    .dash-cards{
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        grid-column-gap: 3rem ;
        padding: 0rem 3rem;
    }

    .card-single{
        background: #fff;
        border-radius: 7px;
        box-shadow: 2px 2px 2px rgb(0,0,0,0.3);
    }
    .card-body {
        padding:1.3rem 1rem;
        display: flex;
        align-items: center;
    }
    .card-body span {
        font-size: 1.5rem;
        color: #777;
        padding-right: 1.4rem;
    }
    .card-body h5{
        color: var(--text-grey);
        font-size: 1rem;
    }
    .card-body h4{
        color: var(--color-dark);
        font-size: 1.1rem; 
        margin-top: .2rem;
    }
    .card-footer {
        padding: 1rem 4rem ;
        background: #f9fafc ;
    }
    .card-footer a {
        color: var(--main-color); 
    }
    
    .recent{
        margin-top: 1rem;
        margin-left: 3rem;
    }
    .activity-grid{
        display: grid ;
        grid-template-columns:75% 25% ;
        grid-column-gap: 1.5rem;
    }
    .activity-card,
    .summary-card,
    .bday-card {
        background : #fff;
        border-radius: 7px;
    }
    .activity-card h3{
        color:var(--text-grey);
        margin:1rem;
    }
    .activity-card table{
        width: 100%;
        border-collapse:collapse
    }
    .activity-card thead{
        background-color:#efefef;
        text-align:left;
    }
    th, td {
        font-size:  18px;
        padding : 1rem 1rem;
        color: var(--color-dark);
    }
    td {
        font-size : 14px;
    }
    tbody tr:nth-child(even){
        background: #f9fafc
    }
    .summary-card
    {
        margin-bottom:1.5rem;
        margin-right : 70px;
        padding-top: .5rem;
        padding-bottom: .5rem;
        
    }
    .summary-single{
        padding: .5rem 1rem;
        display: flex;
        align-items: center;
        
    }
    .summary-single span {
        font-size:1.5rem;
        color: #777;
        padding-right: 1rem;
    }
    .summary-single h5 {
        color:var(--main-color);
        font-size:15px;
        margin-bottom:.2rem !important;
    }
    .summaru-single small {
        font-weight: 700;
        color: var(--text-grey);
    }
    .bday-card{
        padding: 1rem;
        display: flex;
        align-items: center;
    }
</style>

<h2 class="dash-title">Bienvenue !</h2>
<div class="dash-cards">
    {{-- Clients --}}
    <div class="card-single">
        <div class="card-body">
            <span class="ti-briefcase"></span>
            <div>
                <h3></h3>
                <h4>Clients : <span class="badge badge-light">{{$nbclients}}</span></h4>
            </div>
        </div>
        <div class="card-footer">
            <a href="{{ route('client.index')}}"> Voir tout</a>
        </div>
    </div>
    {{-- Categories --}}
    <div class="card-single">
        <div class="card-body">
            <span class="ti-reload"></span>
            <div>
                <h3></h3>
                <h4>Catégories : <span class="badge badge-light">{{$nbcategories}}</span></h4>
            </div>
        </div>
        <div class="card-footer">
            <a href="{{ route('categorie.index')}}">Voir tout</a>
        </div>
    </div>
    {{-- Produits --}}
    <div class="card-single">
        <div class="card-body">
            <span class="ti-reload"></span>
            <div>
                <h3></h3>
                <h4>Produits : <span class="badge badge-light">{{$nbproduits}}</span></h4>
            </div>
        </div>
        <div class="card-footer">
            <a href="{{ route('produit.index')}}">Voir tout</a>
        </div>
    </div>
</div>
<br>
<div class="dash-cards">
    {{-- Commandes --}}
    <div class="card-single">
        <div class="card-body">
            <span class="ti-check-box"></span>
            <div>
                <h3></h3>
                <h4>Commandes : <span class="badge badge-light">{{$nbcommandes}}</span></h4>
            </div>
        </div>
        <div class="card-footer">
            <a href="{{ route('commande.affiche')}}">Voir tout</a>
        </div>
    </div>
    {{-- Reglements --}}
    <div class="card-single">
        <div class="card-body">
            <span class="ti-check-box"></span>
            <div>
                <h3></h3>
                <h4>Règlements : <span class="badge badge-light">{{$nbreglements}}</span></h4>
            </div>
        </div>
        <div class="card-footer">
            <a href="{{ route('commande.index5')}}">Voir tout</a>
        </div>
    </div>
    {{-- Factures --}}
    <div class="card-single">
        <div class="card-body">
            <span class="ti-check-box"></span>
            <div>
                <h3></h3>
                <h4>Factures : <span class="badge badge-light">{{$nbfactures}}</span></h4>
            </div>
        </div>
        <div class="card-footer">
            <a href="{{ route('facture.index')}}">Voir tout</a>
        </div>
        </div>
</div>

<section class="recent">
    <div class="activity-grid">
        <div class="activity-card">
            <h3>Activités récentes</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Clients</th>
                        <th>Catégories</th>
                        <th>Produits</th>
                        <th>Commandes</th>
                        <th>Règlements</th>
                        <th>Factures</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            @if(count($clients)>0) 
                                {{$clients[0]->code}}<br>
                                <span class="badge badge-light">{{$clients[0]->nom_client}}</span>
                            @endif
                        </td>
                        <td>
                            @if(count($categories)>0) 
                                {{$categories[0]->nom_categorie}}
                            @endif
                        </td>
                        <td>
                            @if(count($produits)>0) 
                                {{$produits[0]->code_produit}}
                            @endif
                        </td>
                        <td>
                            @if(count($commandes)>0) 
                                {{$commandes[0]->code}}<br>
                                <span class="badge badge-light">{{$commandes[0]->client->nom_client}}</span>
                            @endif
                        </td>
                        <td>
                            @if(count($reglements)>0) 
                                {{$reglements[0]->code}}<br>
                                <span class="badge badge-light">{{$reglements[0]->commande->client->nom_client}}</span>
                            @endif
                        </td>
                        <td>
                            @if(count($factures)>0) 
                                {{$factures[0]->code}}<br>
                                <span class="badge badge-light">{{$factures[2]->commande->client->nom_client}}</span>
                            @endif
                        </td>
                    </tr>
                    <tr>
                        <td>
                            @if(count($clients)>1) 
                                {{$clients[1]->code}} <br> 
                                <span class="badge badge-light">{{$clients[1]->nom_client}}</span>
                            @endif
                        </td>
                        <td>
                            @if(count($categories)>1) 
                                {{$categories[1]->nom_categorie}}
                            @endif
                        </td>
                        <td>
                            @if(count($produits)>1) 
                                {{$produits[1]->code_produit}}
                            @endif
                        </td>
                        <td>
                            @if(count($commandes)>1) 
                                {{$commandes[1]->code}}<br>
                                <span class="badge badge-light">{{$commandes[1]->client->nom_client}}</span>
                            @endif
                        </td>
                        <td>
                            @if(count($reglements)>1) 
                                {{$reglements[1]->code}}<br>
                                <span class="badge badge-light">{{$reglements[1]->commande->client->nom_client}}</span>
                            @endif
                        </td>
                        <td>
                            @if(count($factures)>1) 
                                {{$factures[1]->code}}<br>
                                <span class="badge badge-light">{{$factures[1]->commande->client->nom_client}}</span>
                            @endif
                        </td>
                    </tr>
                    <tr>
                        <td>
                            @if(count($clients)>2) 
                                {{$clients[2]->code}} <br> 
                                <span class="badge badge-light">{{$clients[2]->nom_client}}</span> 
                            @endif
                        </td>
                        <td>
                            @if(count($categories)>2) 
                                {{$categories[2]->nom_categorie}}
                            @endif
                        </td>
                        <td>
                            @if(count($produits)>2) 
                                {{$produits[2]->code_produit}}
                            @endif
                        </td>
                        <td>
                            @if(count($commandes)>2) 
                                {{$commandes[2]->code}} <br> 
                                <span class="badge badge-light">{{$commandes[2]->client->nom_client}}</span> 
                            @endif
                        </td>
                        <td>
                            @if(count($reglements)>2) 
                                {{$reglements[2]->code}}<br>
                                <span class="badge badge-light">{{$reglements[2]->commande->client->nom_client}}</span>
                            @endif
                        </td>
                        <td>
                            @if(count($factures)>2) 
                                {{$factures[2]->code}}<br>
                                <span class="badge badge-light">{{$factures[2]->commande->client->nom_client}}</span>
                            @endif
                        </td>
                    </tr>  
                </tbody>
            </table>
        </div>
    </div>   
</section>
@endsection