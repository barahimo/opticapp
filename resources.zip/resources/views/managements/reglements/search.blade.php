@extends('layout.dashboard')

@section('contenu')

<h2>hhhhhhhhhhhhhhhh</h2>
@endsection