@extends('layout.dashboard')

@section('contenu')
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="row">
            <div class="col-md-3">
                <h4>Managements Produits</h4>

            </div>

            <div class="col-md-9 text-right">
                <a href="{{route('produit.create')}}" class="btn btn-primary m-b-10 "><i class="fa fa-plus">Nouveau Produit</i></a>
                <a href="{{route('categorie.index')}}" class="btn btn-primary m-b-10  "><i class="far fa-eye">voir tous les catégories</i></a>  
            </div>
            
                    @if(session()->has('status'))
                    <script>
                        Swal.fire('{{ session('status')}}')
                    </script>
                    @endif
            <table class="table">
                <tr>
                    <td scope="col">
                        @include('partials.searchproduit')
                </td>
                </tr>
            </table>

        </div>
        <div class="card" style="background-color: rgba(241, 241, 241, 0.842)">
            <div class="card-body">
                <table class="table" id="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Code</th>
                            <th>Produit</th>
                            <th>TVA</th>
                            <th>prix HT</th>
                            <th>prix TTC</th>
                            <th>Catégorie</th>                            
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($produits as $key=>$produit)
                            <tr>
                                <td>{{$key+1}}</td>
                                <td>{{$produit->code_produit}}</td>
                                <td>{{$produit->nom_produit}}</td>
                                <td>{{$produit->TVA}}%</td>
                                <td>{{number_format($produit->prix_produit_HT,2)}}</td>
                                <td>{{number_format($produit->prix_produit_TTC,2)}}</td>
                                <td>{{$produit->categorie->nom_categorie}}</td>
                                <td>
                                    <a href="{{ action('ProduitController@show',['produit'=> $produit])}}" class="btn btn-secondary btn-md"><i class="fas fa-info"></i></a>
                                    @if( Auth::user()->is_admin )
                                    <a href="{{route('produit.edit',['produit'=> $produit])}}"class="btn btn-success btn-md"><i class="fas fa-edit"></i></a>
                                    <button class="btn btn-danger btn-flat btn-md remove-produit" 
                                    data-id="{{ $produit->id }}" 
                                    data-action="{{ route('produit.destroy',$produit->id) }}"> 
                                    <i class="fas fa-trash"></i>
                                    </button>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
    </div>
    {{ $produits->links()}}
</div>
<script type="text/javascript">
    $(document).ready(function(){
        searchProduit();
        $(document).on('keyup','input[name=q]',function(e){
            e.preventDefault();
            searchProduit();
        });
        $(document).on('click','button[type=submit]',function(e){
            e.preventDefault();
            searchProduit();
        });
    });
    function searchProduit() {
        $.ajax({
            type:'get',
            url:'{!!Route('produit.searchProduit')!!}',
            data:{'search':$('input[name=q]').val()},
            success:function(res){
                var lignes = '';
                var table = $('#table');
                table.find('tbody').html("");
                res.forEach((produit,i) => {
                    var url_show = "{{ action('ProduitController@show',['produit'=> ":id"])}}".replace(':id', produit.id);
                    var url_edit = "{{route('produit.edit',['produit'=> ":id"])}}".replace(':id', produit.id);
                    var url_destroy = "{{ route('produit.destroy',":id") }}".replace(':id', produit.id);
                    var action = `
                        <a href=${url_show} class="btn btn-secondary btn-md"><i class="fas fa-info"></i></a>
                        @if( Auth::user()->is_admin )
                        <a href=${url_edit} class="btn btn-success btn-md"><i class="fas fa-edit"></i></a>
                        <button class="btn btn-danger btn-flat btn-md remove-produit" 
                        data-id="${produit.id}"
                        data-action=${url_destroy} > 
                        <i class="fas fa-trash"></i>
                        </button>
                        @endif
                    `;
                    lignes += `<tr>
                        <td>${i+1}</td>
                        <td>${produit.code_produit}</td>
                        <td>${produit.nom_produit}</td>
                        <td>${produit.TVA}%</td>
                        <td>${parseFloat(produit.prix_produit_HT).toFixed(2)}</td>
                        <td>${parseFloat(produit.prix_produit_TTC).toFixed(2)}</td>
                        <td>${produit.categorie.nom_categorie}</td>
                        <td>${action}</td>
                    </tr>`;
                });
                table.find('tbody').append(lignes);
            },
            error:function(){
                console.log([]);    
            }
        });
    }
    $("body").on("click",".remove-produit",function(){
        var current_object = $(this);
        Swal.fire({
            title: 'Un produit est sur le point de être DÉTRUITE ',
            text: "vous voulez vraiment la supprimer !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'oui, je suis sur!'
            }).then((result) => {
                if (result.isConfirmed) {
                // begin destroy
                        var action = current_object.attr('data-action');
                        var token = jQuery('meta[name="csrf-token"]').attr('content');
                        var id = current_object.attr('data-id');
                        $('body').html("<form class='form-inline remove-form' method='post' action='"+action+"'></form>");
                        $('body').find('.remove-form').append('<input name="_method" type="hidden" value="delete">');
                        $('body').find('.remove-form').append('<input name="_token" type="hidden" value="'+token+'">');
                        $('body').find('.remove-form').append('<input name="id" type="hidden" value="'+id+'">');
                        $('body').find('.remove-form').submit();
                //end destroy
                //    Swal.fire(
                //    'Deleted!',
                //    'Your file has been deleted.',
                //    'success'
                //    )
                }
            })
            // end swal2
    });
</script>
</div>

@endsection



