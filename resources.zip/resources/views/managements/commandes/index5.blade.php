@extends('layout.dashboard')
@section('contenu')
<!-- ##################################################################### -->
<div class="container">
<div>
    <a href="{{route('commande.index2')}}" class="btn btn-primary m-b-10 ">
      <i class="fa fa-plus">&nbsp;Commande</i>
    </a>
    &nbsp;
    <a id="create" href="{{route('reglement.create2')}}" class="btn btn-primary m-b-10 ">
      <i class="fa fa-plus">&nbsp;Règlements</i>
    </a>
  </div>
  <br>
  <div class="row">
    <div class="col-4">
      <select class="form-control" name="client" id="client">
      <option value="">--La liste des clients--</option>
        @foreach($clients as $client)
        <option value="{{$client->id }}">{{ $client->nom_client}}</option>
        @endforeach
      </select>
    </div>
    <div class="col-4">
      <div class="row">
        <div class="col-6">
          <div class="form-check">
            <input type="checkbox" class="form-check-input" name="f" id="f" value="f" checked>
            <label for="f">facturée</label>
          </div>
        </div>
        <div class="col-6">
          <div class="form-check">
              <input type="checkbox" class="form-check-input" name="nf" id="nf" value="nf" checked>
              <label for="nf">Non facturée</label>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-6">
          <div class="form-check">
            <input type="checkbox" class="form-check-input" name="r" id="r" value="r" checked>
            <label for="r">Réglée</label>
          </div>
        </div>
        <div class="col-6">
          <div class="form-check">
            <input type="checkbox" class="form-check-input" name="nr" id="nr" value="nr" checked>
            <label for="nr">Non réglée</label>
          </div>
        </div>
      </div>
    </div>
    <div class="col-4">
      <input type="text" class="form-control" name="search" id="search" placeholder="search ..">
    </div>
  </div>
  <br>
  <div class="card" style="background-color: rgba(241, 241, 241, 0.842)">
    <div class="card-body">
      <table class="table" id="table">
        <thead>
          <tr>
            <th>#</th>
            <th>Date</th>
            <th>Client</th>
            <th>Montant total</th>
            <th>Montant payer</th>
            <th>Reste à payer</th>
            <th style="display : none">Status</th>
            <th style="display : none">Facture</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        </tbody>
      </table>
    </div>
  </div>
</div>
<!-- ---------  BEGIN SCRIPT --------- -->
@include('managements.commandes.script_cmd')
{{-- {!! Html::script( asset('js/cmd.js')) !!}  --}}
{{-- <script src="{{asset('js/index_commande.js')}}"></script> --}}

<!-- ##################################################################### -->
@endsection

