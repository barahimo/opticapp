@extends('layout.dashboard')
@section('contenu')
<!-- ##################################################################### -->

<div class="container">
  <!-- Begin Dates  -->
  <div class="row">
    <div class="col-2"></div>
      <div class="col-4">
      <label for="date1">Date de début :</label>
      <input type="date" class="form-control" name="date1" id="date1" placeholder="date1" value={{$date}}>
    </div> 
    <div class="col-4">
      <label for="date2">Date de fin :</label>
      <input type="date" class="form-control" name="date2" id="date2" placeholder="date2" value={{$date}}>
    </div> 
    <div class="col-2"></div>
  </div>
  <!-- End Dates  -->
  <br>
  <!-- Begin LigneCommande  -->
  <div class="card text-left">
    <div class="card-body">
      <h4 class="card-title">Les mouvements :</h4>
      <div class="card-text">
        <table class="table" id="table" border="1">
          <thead>
            <tr class="text-center">
                <th>Date</th>
                <th>Nature</th>
                <th>N° de pièce</th>
                <th>Débit</th>
                <th>Crédit</th>
            </tr>
          </thead>
          <tbody></tbody>
          <tfoot>
            <tr>
              <th class="text-right" colspan="3">Totaux :</th>
              <th></th>
              <th></th>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  </div>
  <!-- End LigneCommande  -->
</div>
<!-- ##################################################################### -->
<script type="text/javascript">
  $(document).ready(function(){
    getBalance();
    $(document).on('change','#date1',function(){
      getBalance();
    });
    $(document).on('change','#date2',function(){
      getBalance();
    });
  });
  function getBalance(){
    $.ajax({
        type:'get',
        url:'{{Route('commande.getBalance')}}',
        data:{
          'from' : $('#date1').val(),
          'to' : $('#date2').val(),
        },
        success: function(res){
          var table = $('#table');
          table.find('tbody').html("");
          table.find('tfoot').html("");
          var lignes = '';
          var debit = 0;
          var credit = 0;
          var commandes = res.commandes;
          var reglements = res.reglements;
          commandes.forEach(ligne => {
              debit += parseFloat(ligne.total); 
              lignes+=`<tr class="text-center">
                      <td>${ligne.date}</td>
                      <td>BON</td>
                      <td>${ligne.code}</td>
                      <td>${parseFloat(ligne.total).toFixed(2)} DH</td>
                      <td>-</td>
                  </tr>`;
          });
          reglements.forEach(ligne => {
              if(ligne.avance>0){
                credit += parseFloat(ligne.avance); 
                lignes+=`<tr class="text-center">
                        <td>${ligne.date}</td>
                        <td>REGLEMENT</td>
                        <td>${ligne.code}</td>
                        <td>-</td>
                        <td>${parseFloat(ligne.avance).toFixed(2)} DH</td>
                    </tr>`;
              }
          });
          table.find('tbody').append(lignes);
          var foot = `<tr>
                        <th colspan="3" class="text-right">Totaux :</th>
                        <th class="text-center">${parseFloat(debit).toFixed(2)} DH</th>
                        <th class="text-center">${parseFloat(credit).toFixed(2)} DH</th>
                    </tr>`
          table.find('tfoot').append(foot);
        },
        error:function(err){
            Swal.fire("Erreur !");
        },
    });
  }
</script>
<!-- ##################################################################### -->
@endsection

