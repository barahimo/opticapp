<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Calenderier extends Model
{
    protected $table = 'calenderier';
}
